import React from 'react';

const NotFound = () => (
  <div key="404" className="app__not-found app__route">
    <h1>404</h1>
  </div>
);

export default NotFound;
